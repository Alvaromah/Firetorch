# Firetorch
Firetorch is an open-source package that gives you the tools to train and evaluate machine learning models. It's well-suited for complex model architectures like deep neural networks or convolutional networks. This library is designed for ease of use and encourages best practices by leveraging pytorch.

